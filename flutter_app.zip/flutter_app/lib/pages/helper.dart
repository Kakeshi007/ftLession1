import 'package:flutter/material.dart';

class Helper {
  Helper();
  RegExp _email = new RegExp(
      r"^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$");

  Color getColorScore(int score) {
    if (score == 5) {
      return Colors.green[800];
    }
    if (score == 4) {
      return Colors.green[300];
    }
    if (score == 3) {
      return Colors.orange;
    }
    if (score == 2) {
      return Colors.deepOrange;
    }
    if (score == 1) {
      return Colors.red;
    }
    return Colors.blueGrey;
  }

  Color getColorPercent(double percent) {
    if (percent >= 90) {
      return Colors.green[800];
    }
    if (percent < 90 && percent >= 80) {
      return Colors.green[300];
    }
    if (percent < 80 && percent > 60) {
      return Colors.orange;
    }
    if (percent < 60) {
      return Colors.deepOrange;
    }
    return Colors.blueGrey;
  }

  bool isEmail(String str) {
    return _email.hasMatch(str.toLowerCase());
  }
}
